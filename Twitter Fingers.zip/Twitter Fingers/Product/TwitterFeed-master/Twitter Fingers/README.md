Follow these instructions to successfully run the Twitter-Fingerz site via your local host.

1. Unzip the src_tf folder.
2. Copy the src_tf (unzipped) folder to your XAMPP htdocs folder. 
	Ex. C:\xampp\htdocs
3. Double-click the src_tf folder in your htdocs folder.
4. Double-click the 'Twitter Fingers'.
5. Ensure the 'TwitterFingerz.php' file is inside the folder along with: 'TFtesting.php', 'table_design.css', and a 'twitteroauth' folder.
3. Open the XAMPP control panel and ensure the Apache server is running. 
4. In your web browser's address bar, enter "localhost/" plus 
	the path to your 'TwitterFingerz.php' file: 'localhost/Twitter Fingers/TwitterFingerz.php'.
5. The website should open to a table of tweets with user and tweets column headers and 
	a Finance Tweet twitter widget.
6. Lastly, a message that states 'Connection to database successfully'.