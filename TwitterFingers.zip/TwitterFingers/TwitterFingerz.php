<html>
<head>
<!-- Title -->
<title>Tweet Traderz</title>

<script 

type="text/javascript">




</script>
<link rel="stylesheet" href="table_design.css">
<body style ="background-color: #38eeff;">
<h1><font color = “#4099FF”><center>Tweet Trader</center></font></h1>


<!-- <h2><center><center></h2>--> 
</head>

<body>

	<?php require __DIR__. '/tmhOAuth/vendor/autoload.php';
	   /* // connect to mongodb
	   $m =  new MongoDB\Client;

		
	   echo "Connection to database successfully" ."<br>" . PHP_EOL;
	   
	   //select a database
	   $db = $m->test;
	   echo "Database test selected" . "<br>" . PHP_EOL; */
	?>

	

<!-- Scrollable box the stream of tweets will be displayed in -->


<!-- Start the Twitter Stream in a new Window --> 


<style>

h1, h2{
	font-family:cursive;
	text-align: center;
}
table{
	background-color: #38eeff;
}

</style>


<h1>Stream</h1>

<!-- Fucntion for calling countinuos streaming to the page --> 

<form action="http://localhost/src_tf/TwitterFingers/tmhOAuth/StreamAccess.php" method="post" target="_self" id="stream">
</form>


<!--Create button for start streaming--> 


<div align="center">
<button type="submit" form="stream" value="stream">Start Stream</button>
<div>

<!--Create button for stop streaming-->

<!--button id="stop">Stop Stream</button-->


<br>

<h1>Search Tweets</h1>

<div id="searchbox">
<table align="center">

<!--Seach All Box for User-->
<tr>
<td>
<form action="mongoSearch.php" method="get" target="_self" id="all">
<button type="submit" form="all" value="Submit">Search All</button>
<input type="text" name="wholeTweet"><br><br>
</form>
</td>
<!--Search Box for User-->
<td>
<form action="mongoSearchText.php" method="get" target="_self" id="textForm">
<button type="submit" form="textForm" value="Submit">Search Text</button>
<input type="text" name="tweetText"><br><br>
</form>
</td>
<!--Search Box for User-->
<td>
<form action="mongoSearchUsers.php" method="get" target="_self" id="userForm">
<button type="submit" form="userForm" value="Submit">Search Users</button>
<input type="text" name="users"><br><br>
</form>
</td>
</tr>


<!-- <tr>
<form action="mongoSearch.php" method="get" target="_self" id="all">
<button type="submit" form="all" value="Submit">Search All</button>
<input type="text" name="wholeTweet"><br><br>
</form>
</tr>

<tr>
<form action="mongoSearchText.php" method="get" target="_self" id="textForm">
<button type="submit" form="textForm" value="Submit">Search Text</button>
<input type="text" name="tweetText"><br><br>
</form>
</tr>

<tr>
<form action="mongoSearchUsers.php" method="get" target="_self" id="userForm">
<button type="submit" form="userForm" value="Submit">Search Users</button>
<input type="text" name="users"><br><br>
</form>
</tr> -->











<!--



<form action="mongoSearchUsers.php" method="get" target="_blank">
<input type="submit" value="Search Users">
<input type="text" name="users"><br><br>

<form action="mongoSearch.php" method="get" target="_blank">
<input type="submit" value="Search All">
<input type="text" name="all"><br><br>
</form> -->
</table>
</div>


</body>

</html>
