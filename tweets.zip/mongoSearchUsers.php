
<html>
<html>
<head style ="background-color: #FF8C00; font-family: Arial; padding: 0; margin: 0;">
<!-- Title -->
<title>Tweet Traderz</title>

<script type="text/javascript"></script>
<link rel="stylesheet" href="table_design.css">

<div style="background-color: #FF8C00; color:white; width:100%; margin: 0; padding: 0; width: 100%">
	<h1 style="padding-top: 20px; padding-bottom: 20px;"><center><a href="http://localhost/src_tf/TwitterFingers/TwitterFingerz.php">Tweet Traderz<a></center></font></h1>
</div>


<!-- <h2><center><center></h2>--> 
</head>

<body style ="background-color: #FF8C00; font-family: Arial; padding: 0; margin: 0;">
<style type="text/css">
	a{
		text-decoration: none;
		color: inherit;
	}

	#posts{
		padding: 20px 40px 0 40px;
		margin: 20px 20px 20px 20px;
		background-color: white;
		font-size: 20px;
		height: 70%;
    	overflow: auto;

</style>

<div id="posts">
<?php 
echo "<h1>Search Results for: " . $_GET["users"] . "</h1><br>";

require __DIR__. '/tmhOAuth/vendor/autoload.php';
//Connect to MongoDB client
  $m =  new MongoDB\Client;

	   //select a database
	   $db = $m->Tweetdemo;
	   
	   //Select collection
	   $collection = $db->tweetfeed;

	   $cursor =  $collection->find();

	   $count = 0;
	   foreach($cursor as $doc){


	   //$file = fopen("tweets.csv", "w");
	   if($doc["Screen Name"] == $_GET["users"]){
		   echo '<strong>'.$doc["Screen Name"].':</strong> '.$doc["text"] ."<br>" . PHP_EOL ."<br>" . PHP_EOL;
		   $termFound = true;
		   $count = $count + 1;
		}

		//	fputcsv($file,explode(',', $str));
}

	echo "<h2>Number of tweets found: " . $count . "</h2><br>" . PHP_EOL;



	// if($termFound != TRUE)
	// 	echo 'search term not found'."<br>";

?>
</div>
</body>
</html>