<html>

<!-- <form action="theSamePage.php" method="post">
    <input type="submit" name="stockSymbol" value="Add stock symbol" />
</form> -->
<?php 
	// require_once "Quandl.php";
	// $api_key = "XfsBLTQzBVicwFU7Acx2";
	// $quandl = new Quandl();
	// $data = $quandl->getSymbol("WIKI/PRICES");

	$file = fopen("secwiki_tickers.csv", "r") or die("Unable to open file!");

	$rows = array_map('str_getcsv', file('secwiki_tickers.csv'));
	$header = array_shift($rows);
	//print_r($rows);
	$csv = array();
	foreach ($rows as $row) {
  		$csv[] = array_combine($header, $row);
	}

	print_r($csv[0]);



	//$ticker = array_search("Ticker", $stock_info);

	//$symbol  = "ZACKS/HDM";

	// Example 1: Hello Quandl
	// function example1($api_key, $symbol) {
	// 	$quandl = new Quandl();
	// 	return $quandl->getSymbol($symbol);
	// }

	// Modify this call to any `exampleN` to check different samples
	//$data = example1($api_key, $symbol);
	//print_r($data);
 ?>

</html>