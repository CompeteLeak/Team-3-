
<!---Style--> 

<html>
<script type="text/javascript"></script>
<link rel="stylesheet" href="table_design.css">

<div style="background-color: #FF8C00; color:white; width:100%; margin: 0; padding: 0; width: 100%">
  <h1 style="padding-top: 20px; padding-bottom: 20px;"><center><a href="http://localhost/src_tf/TwitterFingers/TwitterFingerz.php">Tweet Traderz Stream<a></center></font></h1>
</div>


<!-- <h2><center><center></h2>--> 
</head>
<body style ="background-color: #e6ecf0; font-style: Arial; padding: 0; margin: 0; align-items: center;">
<style type="text/css">
  a{
    text-decoration: none;
    color: inherit;
  }

  #startStream{
    padding: 20px 20px 0 20px;
    margin: 20px 20px 20px 20px;
    background-color: white;
    height: 650px;
    overflow: auto;
    /*font-size: 40px;*/
  }

  #stream{
    background-color: #FF8C00;
    border: none;
    color: white;
    height: 50px;
    width: 200px;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 20px;
    margin-top: 20px;
    border-radius: 25px;
    outline: none;
  }

  ::-webkit-scrollbar{
    
  }

</style>

<h1>
<center>
<!--Page title-->
<!-- Stream Window -->

<!--Create button for stop streaming-->
<button id="stream" onclick="location.href = 'http://localhost/src_tf/TwitterFingers/TwitterFingerz.php'"">Stop Stream</button>
</center>
</h1> 

<div id="startStream">


<?php 

//start time 
$time_start = microtime(true);


require __DIR__. '/vendor/autoload.php';
require __DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'tmhOAuthExample.php';
$tmhOAuth = new tmhOAuthExample();


//@washingtonpost
//@business
//@YahooFinance

$UsersToFollow = array('follow'    => '2467791, 34713362, 19546277');
//$UsersToFollow = array('track'    => '$GOOGL, $AAPL, $AABA');

//List of stock symbols
$stockSymbol = array('symbol'    => 'GOOGL, AAPL, AABA');



function my_streaming_callback($data, $length, $metrics) {
  $file = __DIR__.'/metrics.txt';


//------------WORKING CODE---------------------//
 
//Users (USER IDs) to follow, a comma seperated list
//global access variables
global $UsersToFollow;
global $stockSymbol;


/*does not work
$users = $UsersToFollow["follow"];

//Array list of users to check and make sure only original tweets are coming in
$checkUsers = explode( ', ', $users );
*/
 
//Json formatted tweet
$tweet = $data .PHP_EOL;

//Transfers json String into an array for easy access
$tweetsArray = json_decode($tweet, true);

//get date 
$current_date = getdate();


/*-------------------------------------- old ------------------------------------------*/

 // $user = $tweetsArray['user']['screen_name'];
 // $text = $tweetsArray['text'];
 // $post = '<strong>'.$user.':</strong> '.$text . "<br>"."<br>".PHP_EOL; 


//foreach($checkUsers as $follows)
//{
		//Only stream that aren't ReTweets(RT)
		if(strcmp(substr($text, 0,2), "RT") != 0 && strcmp(substr($post, 0,1), ":") != 0)
		{
			//Displays the screen name of the user who tweeted
			

      //echo $post;

/*-------------------------------------- old ------------------------------------------*/

    //Connect to MongoDB client
    $m =  new MongoDB\Client;

	   //select a database
	   $db = $m->Tweetdemo;
	   
	   //Select collection
	   $collection = $db->selectCollection('tweetfeed');
		
		//Insert tweet into database
		$doc = $collection->insertOne (["Screen Name" => $tweetsArray['user']['screen_name'], "text" => $tweetsArray['text'], "Date" => ]);

    /*-------------------------------------- new ------------------------------------------*/

     $cursor =  $collection->find();

     foreach($cursor as $doc){


     //$file = fopen("tweets.csv", "w");
        echo "<strong>".$doc["Screen Name"].':</strong> '.$doc["text"] ."<br>" . PHP_EOL ."<br>" . PHP_EOL;

    //  fputcsv($file,explode(',', $str));
    }



    /*-------------------------------------- new ------------------------------------------*/
   }
    /*
    //Test demo
    $pos =  '$GOOGL';

    if (stripos($tweetsArray)){
      $testDemo = $collection->insertOne(['$GOOGL' => $tweetsArray['user']['screen_name'], "text" => $tweetsArray['text']]);
      echo 'hello';
    }*


    
    

	//	}
//}
//---------------------------------------------//

//--------------DO NOT DELETE THE BELOW CODE SECTION----------------//

  //echo json_decode($data, true);// .PHP_EOL;
  /*if (!is_null($metrics)) {
    if (!file_exists($file)) {
      $line = 'time' . "\t" . implode("\t", array_keys($metrics)) . PHP_EOL;
      file_put_contents($file, $line);
    }
    $line = time(oid)me() . "\t" . implode("\t", $metrics) . PHP_EOL;
    file_put_contents($file, $line, FILE_APPEND);
  }*/

//--------------DO NOT DELETE THE ABOVE CODE SECTION----------------//  


  return file_exists(dirname(__FILE__) . '/STOP');
}

//$twitter_feed = array();

/*
$api_url = "https://api.twitter.com/1.1/statuses/filter.json/".$twitter['user'].
  ".json?include_entities=".$twitter['entities'].
  "&include_rts=".$twitter['retweet'].
  "&exclude_replies=".$twitter['exclude_replies'].
  "&contributor_details=".$twitter['contributor_details'].
  "&trim_user=".$twitter['trim_user'].
  "&count=".$twitter['count'];
 
// obtain the results 
 
//$json = file_get_contents($api_url, true);
 
// decode the json response as a PHP array
 
//$decode = json_decode($json, true); */


//Washington Post and ESPN ///Use comma seperated list for followers


$code = $tmhOAuth->streaming_request(
  'POST',
  'https://stream.twitter.com/1.1/statuses/filter.json',
  $UsersToFollow,
  'my_streaming_callback'
);
$tmhOAuth->render_response();

//end time stamp 
$time_end = microtime(true);
$time = $time_end - $time_start;

echo "Current time of script:  $time seconds\n";

?>

</div>


</body>
</html>