<html>
<head style ="background-color: #FF8C00; font-family: Arial; padding: 0; margin: 0;">
<style>
body {font-family: Arial;}

/* Style the tab */
div.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
div.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of buttons on hover */
div.tab button:hover {
    background-color: #ddd;
}

/* Create an active/current tablink class */
div.tab button.active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}

/*Style for navigation bar */
.topnav {
    background-color: #333;
    overflow: hidden;
}
/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Style Navigation */
.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}




</style>


<!-- navigation top bar 
<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'Search')">Search Page</button>
  <button class="tablinks" onclick="openCity(event, 'Statistical Analysis')">Statistical Analysis</button>
  <button class="tablinks" onclick="openCity(event, 'Team')">Team</button> 
</div> -->



</style>
</head>
<body>

<!-- navigation side bar -->
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="TwitterFingerz.php">Home</a>
  <a href="http://localhost/src_tf/TwitterFingers/mongoSearch.php"> Search</a>
  <a href="http://localhost/src_tf/TwitterFingers/StatsAnalysis.html">Statistical Analysis</a>
  <a href="http://localhost/src_tf/TwitterFingers/team.html">Team</a>
</div>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>



<!-- navigation top bar 
<div id="Search" class="tabcontent">

  <h3><a href = "mongoSearch.php">Click here for Search Page </a></h3>
  <p>Navigate to search page.</p>
</div>

<div id="Statistical Analysis" class="tabcontent">
  <h3><a href="StatsAnalysis.html">Click Here for Statistical Analysis</a></h3>
  <p>Statistical Analysis Page</p> 
</div>

<div id="Team" class="tabcontent">
  <h3><a href="team.html">Click Here for Team Page </a></h3>
  <p>Breif description of memebers that made this happen.</p>
</div> 

<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
</script> -->



<!-- Title -->
<title>Tweet Traderz</title>

<script type="text/javascript"></script>
<link rel="stylesheet" href="table_design.css">

<div style="background-color: #FF8C00; color:white; width:100%; margin: 0; padding: 0; font-style: Arial;">
	<h1 style="padding-top: 20px;"><center>Tweet Traderz</center></font></h1>
	<ul>
		<li>
			
		</li>
		<form action="mongoSearch.php" method="get" target="_self" id="all">
<!-- <button type="submit" form="all" value="Submit">Search All</button> -->
<input style="float: right;" type="text" name="wholeTweet" placeholder="Search Tweets and Users..."><br><br>
</form>
	</ul>
</div>


<!-- <h2><center><center></h2>--> 
</head>

<body style ="background-color: #e6ecf0; font-style: Arial; padding: 0; margin: 0;">

	<?php require __DIR__. '/tmhOAuth/vendor/autoload.php';
	   /* // connect to mongodb
	   $m =  new MongoDB\Client;

		
	   echo "Connection to database successfully" ."<br>" . PHP_EOL;
	   
	   //select a database
	   $db = $m->test;
	   echo "Database test selected" . "<br>" . PHP_EOL; */
	?>

	

<!-- Scrollable box the stream of tweets will be displayed in -->


<!-- Start the Twitter Stream in a new Window --> 


<style>

/*h1, h2{
	font-family:cursive;
	text-align: center;
}*/

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

table{
	background-color: white;
}


#streamButton{

	/**background-color: #FF8C00;
    border: none;
    color: white;
    height: 200px;
    width: 75%;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 80px;
    margin-top: 40px;
    border-radius: 25px;
    outline: none; **/ 
     padding: 15px 25px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color:  #FF8C00;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;

}
#streamButton:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}

input[type=text] {
		
    width: 275px;
    height: 40px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 25px;
    font-size: 16px;
    background-color: white;
    background-image: url('https://images.vexels.com/media/users/3/132068/isolated/preview/f9bb81e576c1a361c61a8c08945b2c48-search-icon-by-vexels.png');
    background-size: 20px 20px;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
    margin: 5px 5px 0 0; 
    outline: none; 
     background-image: url('https://images.vexels.com/media/users/3/132068/isolated/preview/f9bb81e576c1a361c61a8c08945b2c48-search-icon-by-vexels.png');
}

input[type=text]:focus {
    width: 50%;
}

#loading{
	margin-top: 150px;
	display: none;
	border: 26px solid gray;
	border-radius: 50%;
	border-top: 26px solid #FF8C00;
	width: 250px;
	height: 250px;
	-webkit-animation: spin 2s linear infinite;
	animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>


<!-- <h1>Stream</h1> -->

<!-- Fucntion for calling countinuos streaming to the page --> 

<form action="http://localhost/src_tf/TwitterFingers/tmhOAuth/StreamAccess.php" method="post" target="_self" id="stream">
</form>


<!--Create button for start streaming--> 


<div align="center">
<button id="streamButton" type="submit" form="stream" value="Start Stream" onclick="loading()">Stream</button>
<div id="loading"><div>
<div>
<script>
	function loading(){
		var x = document.getElementById("streamButton");
		var y = document.getElementById("loading");
		x.style.display = "none";
		y.style.display = "block";
	}
</script>

<!--Create button for stop streaming-->

<!--button id="stop">Stop Stream</button-->


<br>


<div id="searchbox">
<!-- <table align="center" id="searchButton"> -->

<!--Seach All Box for User-->
<!-- <tr>
	<td colspan="3"><h1 style="color:black; font-style: Arial;">Search Tweets</h1></td>
</tr>
<tr>
<td>
<form action="mongoSearch.php" method="get" target="_self" id="all">
<button type="submit" form="all" value="Submit">Search All</button>
<input type="text" name="wholeTweet"><br><br>
</form>
</td> -->
<!--Search Box for User-->
<!-- <td>
<form action="mongoSearchText.php" method="get" target="_self" id="textForm">
<button type="submit" form="textForm" value="Submit">Search Text</button>
<input type="text" name="tweetText"><br><br>
</form>
</td> -->
<!--Search Box for User-->
<!-- <td>
<form action="mongoSearchUsers.php" method="get" target="_self" id="userForm">
<button type="submit" form="userForm" value="Submit">Search Users</button>
<input type="text" name="users"><br><br>
</form>
</td>
</tr>


<tr>
<form action="mongoSearch.php" method="get" target="_self" id="all">
<button type="submit" form="all" value="Submit">Search All</button>
<input type="text" name="wholeTweet"><br><br>
</form>
</tr>

<tr>
<form action="mongoSearchText.php" method="get" target="_self" id="textForm">
<button type="submit" form="textForm" value="Submit">Search Text</button>
<input type="text" name="tweetText"><br><br>
</form>
</tr>

<tr>
<form action="mongoSearchUsers.php" method="get" target="_self" id="userForm">
<button type="submit" form="userForm" value="Submit">Search Users</button>
<input type="text" name="users"><br><br>
</form>
</tr>



<form action="mongoSearchUsers.php" method="get" target="_blank">
<input type="submit" value="Search Users">
<input type="text" name="users"><br><br>

<form action="mongoSearch.php" method="get" target="_blank">
<input type="submit" value="Search All">
<input type="text" name="all"><br><br>
</form> -->
<!-- </table>
 --></div>


</body>

</html>
