<html>
<head style ="background-color: #FF8C00; font-family: Arial; padding: 0; margin: 0;">
<style>
body {font-family: Arial;}

/* Style the tab */
div.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
div.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of buttons on hover */
div.tab button:hover {
    background-color: #ddd;
}

/* Create an active/current tablink class */
div.tab button.active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}
</style>

<style>
body {font-family: Arial;}

/* Style the tab */
div.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
div.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of buttons on hover */
div.tab button:hover {
    background-color: #ddd;
}

/* Create an active/current tablink class */
div.tab button.active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}

/*Style for navigation bar */
.topnav {
    background-color: #333;
    overflow: hidden;
}
/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Style Navigation */
.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}




</style>

<!--  <div class="tab">
  <button class="tablinks" onclick="openCity(event, 'Home')">Home</button>
  <button class="tablinks" onclick="openCity(event, 'Statistical Analysis')">Statistical Analysis</button>
  <button class="tablinks" onclick="openCity(event, 'Team')">Team</button>
</div>

<div id="Home" class="tabcontent"> 

  <h3><a href = "TwitterFingerz.php">Home</center></h3>
  <p>Return to home page.</p>
</div>

<div id="Statistical Analysis" class="tabcontent">
  <h3><a href="StatsAnalysis.html">Statistical Analysis</a></h3>
  <p>Statistical Analysis Page</p> 
</div>

<div id="Team" class="tabcontent">
  <h3><a href="team.html">Team</a></h3>
  <p>Team Page.</p>
</div> -->

<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
</script>
<!-- Title -->
<title>Tweet Traderz </title>

<script type="text/javascript"></script>
<link rel="stylesheet" href="table_design.css">

<div style="background-color: #FF8C00; color:white; margin: 0; padding: 0; width: 100%">
	
	<ul>
		<!-- <li id="user">
			<form action="mongoSearchUsers.php" method="get" target="_self" id="userForm">
			<input type="text" name="users" placeholder="Search Only Users...">
			</form>
		</li> </!-->
		<li id="text">
			<form action="mongoSearchText.php" method="get" target="_self" id="textForm">
			<input type="text" name="tweetText" placeholder="Search Only Tweets...">
			</form>
		</li>
	</ul>
</div>




<!-- <h2><center><center></h2>--> 
</head>
<body style ="background-color: #FF8C00; font-family: Arial; padding: 0; margin: 0;">
<style type="text/css">
	a{
		text-decoration: none;
		color: inherit;
	}

	#posts{
		padding: 20px 40px 20px 40px;
		margin: 20px 20px 20px 20px;
		background-color: white;
		font-size: 20px;
		height: 70%;
    	overflow: auto;
	}

	input[type=text] {
	    width: 200px;
	    height: 40px;
	    box-sizing: border-box;
	    border: 2px solid #ccc;
	    border-radius: 25px;
	    font-size: 16px;
	    background-color: white;
	    background-image: url('https://images.vexels.com/media/users/3/132068/isolated/preview/f9bb81e576c1a361c61a8c08945b2c48-search-icon-by-vexels.png');
	    background-size: 20px 20px;
	    background-position: 10px 10px; 
	    background-repeat: no-repeat;
	    padding: 12px 20px 12px 40px;
	    -webkit-transition: width 0.4s ease-in-out;
	    transition: width 0.4s ease-in-out;
	    margin-top: 5px; 
	}

	ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
	}

	#text{
	    float: right;
	}
	#user{
		float: left;
	}

</style>

<body>

<!-- navigation side bar -->
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="TwitterFingerz.php">Home</a>
  <a href="http://localhost/src_tf/TwitterFingers/team.html">Team</a>
   <a href="http://localhost/src_tf/TwitterFingers/StatsAnalysis.html">Statistical Analysis</a>
</div>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>



<div id="posts">
<?php 
echo "<h1>Search Results for: " . $_GET["wholeTweet"] . "</h1><br>";

require __DIR__. '/tmhOAuth/vendor/autoload.php';
//Connect to MongoDB client
  $m =  new MongoDB\Client;

	   //select a database
	   $db = $m->Tweetdemo;
	   
	   //Select collection
	   $collection = $db->tweetfeed;

	   $cursor =  $collection->find();

	   $count = 0;
	   foreach($cursor as $doc){


	   //$file = fopen("tweets.csv", "w");
	   if(stripos($doc["text"] . $doc["Screen Name"], $_GET["wholeTweet"]) != false){
		   echo "<strong>".$doc["Screen Name"].':</strong> '.$doc["text"] ."<br>" . PHP_EOL ."<br>" . PHP_EOL;
		   $termFound = true;
		   $count = $count + 1;
		}

		//	fputcsv($file,explode(',', $str));
}

	echo "<h2>Number of tweets found: " . $count . "</h2><br>" . PHP_EOL;



	if($termFound != TRUE)
		echo 'search term not found'."<br>";

?>
</div>
<h1 style="padding-top: 20px; padding-bottom: 20px;"><center>Tweet Traderz Search Page</center></font></h1>
</body>
</html>